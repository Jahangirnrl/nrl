
  LiquidCrystal_I2C lcd(0x27, 16, 2); // Initialize LCD Display at address 0x27
  #define BUFF_MAX 128


  uint8_t time[8];
  char recv[BUFF_MAX];
  unsigned int recv_size = 0;
  unsigned long prev, interval = 1000;

  
    //Serial.println("Setting time");       //---------CLOCK SET FIRST TIME TO UNCOMMENT THIS LINE
    //parse_cmd("T193312631102018",16);     //---------CLOCK SET FIRST TIME TO UNCOMMENT THIS LINE ALSO
    //parse_cmd("TssmmhhWDDMMYYYY",16);   //-----------CLOCK SET WITH THIS FORMAT


  void parse_cmd(char *cmd, int cmdsize)
    {
    uint8_t i;
    uint8_t reg_val;
    char buff[BUFF_MAX];
    struct ts t;
    }
  
  void printWeek (int week)
  {
    switch (week)
    {
      case 1:   lcd.print("Fr"); break;
      case 2:   lcd.print("Sa"); break;
      case 3:   lcd.print("Su"); break;
      case 4:   lcd.print("Mo"); break;
      case 5:   lcd.print("Tu"); break;
      case 6:   lcd.print("We"); break;
      case 7:   lcd.print("Th"); break;
      default:  lcd.print("Er"); break;
    }
  }
  
  void printMonth(int month)
  {
    switch (month)
    {
      case 1:   lcd.print("01"); break;
      case 2:   lcd.print("02"); break;
      case 3:   lcd.print("03"); break;
      case 4:   lcd.print("04"); break;
      case 5:   lcd.print("05"); break;
      case 6:   lcd.print("06"); break;
      case 7:   lcd.print("07"); break;
      case 8:   lcd.print("08"); break;
      case 9:   lcd.print("09"); break;
      case 10:  lcd.print("10"); break;
      case 11:  lcd.print("11"); break;
      case 12:  lcd.print("12"); break;
      default:  lcd.print("Err"); break;
    }
  }
